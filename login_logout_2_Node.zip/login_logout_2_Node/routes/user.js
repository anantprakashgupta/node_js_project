exports.signup = function(req, res){
    message = '';
    if(req.method == "POST"){
       //post data
 
    } else {
       res.render('signup');
    }
 };

 exports.login = function(req, res){
    var message = '';
    var sess = req.session; 
 
    if(req.method == "POST"){
       var post  = req.body;
       var name= post.username;
       var pass= post.password;
      
       var sql="SELECT username, password FROM `login` WHERE `username`='"+name+"' and password = '"+pass+"'";                           
       db.query(sql, function(err, results){      
          if(results.length){
             req.session.id = results[0].id;
             req.session.user = results[0];
             console.log(results[0].id);
             res.redirect('/home/dashboard');
          }
          else{
             message = 'Wrong Credentials.';
             res.render('index.ejs',{message: message});
          }
                  
       });
    } else {
       res.render('index.ejs',{message: message});
    }         
 };