
var con = require('./connection');
var multer = require("multer");
var express = require('express');
var app = express();
var session = require('express-session');
var flash = require('connect-flash');
var flash = require('express-flash');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
const { createConnection } = require('net');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use("/assets", express.static("assets"));
app.use(cookieParser());
//response.setHeader("Content-Type", "text/html");

app.get('/', function (req, res) {
  //res.sendFile(__dirname + '/register.html');
  res.render(__dirname + "/register", { success3: '' })

  app.use(session({
    secret: 'codeforgeek',
    cookie: { maxAge: 6000 },
    saveUninitialized: true,
    resave: true
  }));

  app.use(flash);

});
app.post('/', function (req, res) {
  console.log(req.body);
  var name = req.body.name;
  var email = req.body.email;
  var mno = req.body.mno;

  con.connect(function (error) {
    if (error) throw error;

    var sql = "INSERT INTO college(name, email, mno) VALUES (?, ?,?)";

    con.query(sql, [name, email, mno], function (error, result) {
      if (error) throw error;
      res.render(__dirname + "/register", { success3: 'Register Successfull' })
      //res.redirect('/college');
    });
  });


});

app.get('/college', function (req, res) {
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "select * from college";
    con.query(sql, function (error, result) {
      if (error) console.log(error);
      res.render(__dirname + "/students", { Students: result, success: 'show all list' })
    });
  })
});


app.get('/delete-student', function (req, res) {
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "delete from college where id=?";
    var id = req.query.id;
    con.query(sql, [id], function (error, result) {

      if (error) console.log(error);
      res.redirect('/college');
    });
  })

});


app.get('/update-students', function (req, res) {
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "select * from college where id=?";
    var id = req.query.id;
    con.query(sql, [id], function (error, result) {

      if (error) console.log(error);
      res.render(__dirname + "/update-students", { student: result })
    });
  })

});

app.post('/update-students', function (req, res) {
  var name = req.body.name;
  var email = req.body.email;
  var mno = req.body.mno;
  var id = req.body.id;
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "UPDATE  college set name=?,  email=?, mno=? where  id=?";
    con.query(sql, [name, email, mno, id], function (error, result) {
      if (error) console.log(error);
      res.redirect('/college');

    });
  })
});


app.get('/search-students', function (req, res) {
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "select * from college";
    con.query(sql, function (error, result) {
      if (error) console.log(error);
      res.render(__dirname + "/search-students", { Students: result, success5: ''})
    });
  })
});

app.get('/search', function (req, res) {
  var name = req.query.name;
  var email = req.query.email;
  var mno = req.query.mno;

  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "SELECT * from college where name LIKE '%" + name + "%'  AND email LIKE '%" + email + "%' AND mno LIKE '%" + mno + "%'";

    con.query(sql, function (error, result) {
      if (error) console.log(error);
      res.render(__dirname + "/search-students", { Students: result, success5: 'Data not found'})
      
      console.log(name);
    });
  });

});

app.get('/search', function (req, res) {
  res.render(__dirname + "/search-students")
});

app.get('/search', function (req, res) {
  con.query('SELECT name from college where name like "%' + req.query.term + '%"',
    function (err, rows) {
      if (err) throw err;
      var data = [];
      for (i = 0; i < rows.length; i++) {
        data.push(rows[i].name);
      }
      res.end(JSON.stringify(data));
      console.log(i);
    });
});



// app.all('/session-flash', function( req, res ) {
//     req.session.sessionFlash = {
//         type: 'success',
//         message: 'This is a flash message using custom middleware and express-session.'
//     }
//     res.redirect(301, '/');
// });

app.get('/login', function (req, res) {
  // res.sendFile(__dirname+"/login.html")
  res.render(__dirname + "/login", { success4: '' })
})

app.post('/login', function (request, response) {
  // Capture the input fields
  let email = request.body.email;
  let mno = request.body.mno;
  let name = request.body.name;

  if (email && mno) {
    // Execute SQL query that'll select the account from the database based on the specified username and password
    con.query('SELECT * FROM college WHERE email = ? AND mno = ?', [email, mno], function (error, results) {
      //serverSuccess:request.flash('server-success', 'user login sucess');
      if (error) throw error;
      // If the account exists
      if (results.length > 0) {
        response.render(__dirname + "/login", { success4: 'Login successfully !' })
        //response.redirect('/college');

      } else {
        response.render(__dirname + "/login", { success4: 'wrong password' })
        //response.send('Incorrect Username or Password!');

      }
      response.end();
    });
  } else {

    response.send('Please enter Username and Password!');
    response.end();
  }
});
//////////////////////////upload file ///////////////////////////////////////
app.get('/fileupload', function (req, res) {
  //es.sendFile(__dirname + '/fileupload.ejs');
  res.render(__dirname + "/fileupload", { success2: '' })
});

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads')
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now())
  }
})

var upload = multer({ storage: storage })

app.post('/uploadfile', upload.single('myFile'), (req, res, next) => {
  const file = req.file
  if (!file) {
    //  res.render('index', {message : req.flash('success')});
    res.render(__dirname + "/fileupload", { success2: 'please upload' })
    const error = new Error('Please upload a file')
    error.httpStatusCode = 400
    return next(error)
  }
  res.render(__dirname + "/fileupload", { success2: 'file upload successfull' })
  res.send(file)

})
//////////////file from folder /////////////////////

const fs = require("fs");
let directory_name = "/home/prakash/Desktop";
let filenames = fs.readdirSync(directory_name);

console.log("\nFilenames in directory:");
filenames.forEach((file) => {
  console.log("File:", file);
});
/////////////////////////// image upload to db//////////////////////////////

app.get('/photo', (req, res) => {
  con.connect(function (err) {
    res.sendFile(__dirname + '/index.html');
  });
  //@type   POST
  //route for post data
  app.post("/post", upload.single('image'), (req, res) => {

    var storage = multer.diskStorage({
      destination: (req, file, callBack) => {
        callBack(null, './home/prakash/Desktop')     // './public/images/' directory name where save the file
      },
      filename: (req, file, callBack) => {
        callBack(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
      }
    })
    var upload = multer({
      storage: storage
    });
    if (!req.file) {
      console.log("No file upload");
    } else {
      console.log(req.file.filename)
      var imgsrc = 'http://localhost:8000/uploads/' + req.file.filename
      var insertData = "INSERT INTO users_file(file)VALUES(?)"
      con.query(insertData, [imgsrc], (err, result) => {
        if (err) err
        console.log("file uploaded")
      })

    }
  })
});
////////////////////////////// pagination //////////////////////////////////////

const resultsPerPage =5;

app.get('/page', (req, res) => {
    let sql = 'SELECT * FROM Pagination2';
    con.query(sql, (err, result) => {
        if(err) throw err;
        const numOfResults = result.length;
        const numberOfPages = Math.ceil(numOfResults / resultsPerPage);
        let page = req.query.page ? Number(req.query.page) : 1;
        if(page > numberOfPages){
            res.redirect('/?page='+encodeURIComponent(numberOfPages));
        }else if(page < 1){
            res.redirect('/?page='+encodeURIComponent('1'));
        }
        //Determine the SQL LIMIT starting number
        const startingLimit = (page - 1) * resultsPerPage;
        //Get the relevant number of POSTS for this starting page
        sql = `SELECT * FROM  Pagination2 LIMIT ${startingLimit},${resultsPerPage}`;
        con.query(sql, (err, result)=>{
            if(err) throw err;
            let iterator = (page - 5) < 1 ? 1 : page - 5;
            let endingLink = (iterator + 9) <= numberOfPages ? (iterator + 9) : page + (numberOfPages - page);
            if(endingLink < (page + 4)){
                iterator -= (page + 4) - numberOfPages;
            }
            //res.render('index', {data: result, page, iterator, endingLink, numberOfPages});
            res.render(__dirname +'/index', { data: result, page, iterator, endingLink, numberOfPages });
        });
    });
});
/////////////////////insert and display image///////////////////

app.get('/photos', function (req, res) {
  res.sendFile(__dirname + '/photoDb.html');
  //res.render("");
});

var upload = multer({
  dest: 'uploads/',
  storage: multer.memoryStorage()
});

app.post("/photoPC",upload.single('ProductImage'),(req, res)=>{
  image =req.file.buffer.toString('base64')
  name2= req.body.product
  price = req.body.price

  
   q = "INSERT INTO product VALUES (NULL,?, ?,NULL,?)";
  con.query(q, [name2, price, image],(err,rows, fields)=>{
    if(err) throw err;
    res.render(__dirname + "/products", { viewImage: result})
  })
})

app.get('/pd', function (req, res) {
  con.connect(function (error) {
    if (error) console.log(error);
    var sql = "select * from product";
    con.query(sql, function (error, result) {
      if (error) console.log(error);
     // res.render(__dirname + "/products", {Products: result})
      res.render(__dirname + "/products", { viewImage: result})
    });
  })
});

/////////////////////////////////////////




app.listen(8000);

